// -*- C++ -*- compatibility header.
// This file is part of the GNU ANSI C++ Library.

#include <algorithm>
#include <deque>
#include <functional>
#include <iterator>
#include <list>
#include <map>
#include <memory>
#include <numeric>
#include <set>
#include <stack>
#include <utility>
#include <vector>
